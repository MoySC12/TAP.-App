package com.luis.home

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.imaginativeworld.whynotimagecarousel.ImageCarousel
import org.imaginativeworld.whynotimagecarousel.model.CarouselItem

class MainActivity : AppCompatActivity() {

    val banners = mutableListOf<CarouselItem>()
   // val botones = arrayOf(findViewById<ImageButton>(R.id.pop1),
     //findViewById(R.id.pop2),
     //findViewById(R.id.pop3),
     //findViewById(R.id.pop4))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        iniciarCarrusel()


    }

    fun iniciarCarrusel(){
        val carousel: ImageCarousel = findViewById(R.id.carousel)
        banners.add(CarouselItem(R.drawable.banner))
        banners.add(CarouselItem(R.drawable.banner2))
        banners.add(CarouselItem(R.drawable.banner3))
        carousel.autoPlay=true
        carousel.autoPlayDelay=3000
        carousel.showNavigationButtons = false
        carousel.showTopShadow=false
        carousel.showBottomShadow=false
        carousel.addData(banners)
    }




}