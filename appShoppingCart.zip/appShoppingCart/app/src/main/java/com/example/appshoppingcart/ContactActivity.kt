package com.example.appshoppingcart

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class ContactActivity : AppCompatActivity(), BottomNavigationView.OnNavigationItemSelectedListener {

        var tel: TextView?=null
        var CE: TextView?=null
        //------
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.contact_layout)

            val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottom_nav_view)
            bottomNavigationView.setOnNavigationItemSelectedListener(this)

            tel=findViewById(R.id.numTel)
            CE=findViewById(R.id.correoElectronico)
            val copy1:Button=findViewById(R.id.copyTel)
            val copy2:Button=findViewById(R.id.copyCE)
            //------
            copy1.setOnClickListener {
                val textToCopy = tel?.text.toString()
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("label", textToCopy)
                clipboard.setPrimaryClip(clip)
                Toast.makeText(this, "Número copiado", Toast.LENGTH_LONG).show()
            }
            //------
            copy2.setOnClickListener {
                val textToCopy = CE?.text.toString()
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("label", textToCopy)
                clipboard.setPrimaryClip(clip)
                Toast.makeText(this, "Correo copiado", Toast.LENGTH_LONG).show()
            }
        }
        override fun onNavigationItemSelected(item: MenuItem): Boolean {
            when (item.itemId) {
                R.id.nav_cart -> {
                    startActivity(Intent(this, CartActivity::class.java))
                    return true
                }
                R.id.nav_product -> { //Ir a login
                    startActivity(Intent(this, ContactActivity::class.java))
                    return true
                }
                R.id.nav_main -> {
                    // Ir a la actividad principal
                    startActivity(Intent(this, MainActivity::class.java))
                    return true
                }
            }
            return false
        }
    }