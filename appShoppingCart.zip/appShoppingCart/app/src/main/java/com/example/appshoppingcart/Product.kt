package com.example.appshoppingcart

data class Product(val name: String, val size: String, val color: String, var quantity: Int = 1)
