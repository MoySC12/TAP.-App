package com.example.appshoppingcart

interface CartUpdateListener {
    fun onCartUpdated()
}