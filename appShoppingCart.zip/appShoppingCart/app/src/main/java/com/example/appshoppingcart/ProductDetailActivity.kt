package com.example.appshoppingcart

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class ProductDetailActivity : AppCompatActivity(), BottomNavigationView.OnNavigationItemSelectedListener  {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_detail)

        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottom_nav_view)
        bottomNavigationView.setOnNavigationItemSelectedListener(this)

        val productName = intent.getStringExtra("productName")
        val sizes = intent.getStringArrayExtra("sizes")
        val colors = intent.getStringArrayExtra("colors")

        val textProductName = findViewById<TextView>(R.id.text_product_name)
        val spinnerSizes = findViewById<Spinner>(R.id.spinner_sizes)
        val spinnerColors = findViewById<Spinner>(R.id.spinner_colors)
        val buttonAddToCart = findViewById<Button>(R.id.button_add_to_cart)

        textProductName.text = productName
        spinnerSizes.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, sizes!!)
        spinnerColors.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, colors!!)

        buttonAddToCart.setOnClickListener {
            // Lógica para agregar al carrito
            val selectedSize = spinnerSizes.selectedItem.toString()
            val selectedColor = spinnerColors.selectedItem.toString()
            val product = Product(productName!!, selectedSize, selectedColor)
            Cart.addProduct(product)

            // Mostrar un Toast
            Toast.makeText(this, "$productName agregado al carrito", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_cart -> {
                startActivity(Intent(this, CartActivity::class.java))
                return true
            }
            R.id.nav_product -> {
                startActivity(Intent(this, ContactActivity::class.java))
                return true
            }
            R.id.nav_main -> {
                // Ir a la actividad principal
                startActivity(Intent(this, MainActivity::class.java))
                return true
            }
        }
        return false
    }
}
