package com.example.appshoppingcart

object Cart {
    private val products = mutableListOf<Product>()

    fun addProduct(product: Product) {
        products.add(product)
    }

    fun getProducts(): List<Product> {
        return products
    }

    fun removeProduct(product: Product) {
        products.remove(product)
    }
}

