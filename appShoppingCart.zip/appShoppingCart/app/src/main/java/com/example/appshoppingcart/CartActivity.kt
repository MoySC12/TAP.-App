package com.example.appshoppingcart

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.LinearLayout

class CartActivity : AppCompatActivity(), CartUpdateListener {

    private lateinit var cartAdapter: CartAdapter
    private lateinit var emptyCartLayout: LinearLayout
    private lateinit var recyclerViewCart: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        emptyCartLayout = findViewById(R.id.empty_cart_layout)
        recyclerViewCart = findViewById(R.id.recycler_view_cart)

        cartAdapter = CartAdapter(Cart.getProducts().toMutableList(), this)
        recyclerViewCart.layoutManager = LinearLayoutManager(this)
        recyclerViewCart.adapter = cartAdapter

        updateCartStatus()
    }

    override fun onCartUpdated() {
        updateCartStatus()
    }

    private fun updateCartStatus() {
        if (Cart.getProducts().isEmpty()) {
            emptyCartLayout.visibility = android.view.View.VISIBLE
            recyclerViewCart.visibility = android.view.View.GONE
        } else {
            emptyCartLayout.visibility = android.view.View.GONE
            recyclerViewCart.visibility = android.view.View.VISIBLE
        }
    }

    override fun onResume() {
        super.onResume()
        cartAdapter.notifyDataSetChanged()
        updateCartStatus()
    }
}