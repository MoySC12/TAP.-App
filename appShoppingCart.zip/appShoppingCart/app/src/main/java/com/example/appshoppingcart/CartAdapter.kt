package com.example.appshoppingcart

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class CartAdapter(private val products: MutableList<Product>, private val cartUpdateListener: CartUpdateListener) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_cart, parent, false)
        return CartViewHolder(view)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val product = products[position]
        holder.bind(product)
    }

    override fun getItemCount() = products.size

    inner class CartViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val productName: TextView = itemView.findViewById(R.id.text_product_name)
        private val productDetails: TextView = itemView.findViewById(R.id.text_product_details)
        private val quantityEditText: EditText = itemView.findViewById(R.id.edit_text_quantity)
        private val increaseButton: Button = itemView.findViewById(R.id.button_increase)
        private val decreaseButton: Button = itemView.findViewById(R.id.button_decrease)
        private val removeButton: Button = itemView.findViewById(R.id.button_remove)

        fun bind(product: Product) {
            productName.text = product.name
            productDetails.text = "Talla: ${product.size}, Color: ${product.color}"
            quantityEditText.setText(product.quantity.toString())

            removeButton.setOnClickListener {
                products.remove(product)
                notifyDataSetChanged()
                cartUpdateListener.onCartUpdated()
            }

            increaseButton.setOnClickListener {
                product.quantity++
                quantityEditText.setText(product.quantity.toString())
            }

            decreaseButton.setOnClickListener {
                if (product.quantity > 1) {
                    product.quantity--
                    quantityEditText.setText(product.quantity.toString())
                }
            }
        }
    }
}
