package com.example.appshoppingcart

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity(), BottomNavigationView.OnNavigationItemSelectedListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottom_nav_view)
        bottomNavigationView.setOnNavigationItemSelectedListener(this)

        val buttonShirt = findViewById<Button>(R.id.button_shirt)
        val buttonShoes = findViewById<Button>(R.id.button_shoes)
        val buttonBall = findViewById<Button>(R.id.button_ball)
        val buttonShorts = findViewById<Button>(R.id.button_shorts)
        val buttonCart = findViewById<Button>(R.id.button_cart)

        buttonShirt.setOnClickListener {
            openDetailActivity("Playera", arrayOf("S", "M", "L"), arrayOf("Rojo", "Azul", "Verde"))
        }

        buttonShoes.setOnClickListener {
            openDetailActivity("Tenis", arrayOf("7", "8", "9"), arrayOf("Blanco", "Negro"))
        }

        buttonBall.setOnClickListener {
            openDetailActivity("Balón", arrayOf("Única"), arrayOf("Blanco", "Negro"))
        }

        buttonShorts.setOnClickListener {
            openDetailActivity("Shorts", arrayOf("S", "M", "L"), arrayOf("Negro", "Azul"))
        }

        buttonCart.setOnClickListener {
            val intent = Intent(this, CartActivity::class.java)
            startActivity(intent)
        }
    }


    private fun openDetailActivity(productName: String, sizes: Array<String>, colors: Array<String>) {
        val intent = Intent(this, ProductDetailActivity::class.java)
        intent.putExtra("productName", productName)
        intent.putExtra("sizes", sizes)
        intent.putExtra("colors", colors)
        startActivity(intent)
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_cart -> {
                startActivity(Intent(this, CartActivity::class.java))
                return true
            }
            R.id.nav_product -> {
                startActivity(Intent(this, ContactActivity::class.java))
                return true
            }
            // Ir a login
            R.id.nav_main -> {
                return true
            }
        }
        return false
    }
}
