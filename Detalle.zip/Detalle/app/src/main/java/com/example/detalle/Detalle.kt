package com.example.detalle

import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageButton
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.denzcoskun.imageslider.ImageSlider
import com.denzcoskun.imageslider.models.SlideModel


class Detalle : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_detalle)

        val backBttn = findViewById<ImageButton>(R.id.backBttn)
        backBttn.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        val comentariosBttn = findViewById<Button>(R.id.comentariosBttn)
        comentariosBttn.setOnClickListener{

            startActivity(Intent(this, Comentarios::class.java))
        }


        val productName = intent.getStringExtra("productName")
        val productPrice = intent.getStringExtra("productPrice")
        val sizes = intent.getStringArrayExtra("sizes")
        val colors = intent.getStringArrayExtra("colors")
        val pop =  intent.getStringExtra("pop")
        val pop2 =  intent.getStringExtra("pop2")
        val pop3 = intent.getStringExtra("pop3")
        val productDescription = intent.getStringExtra("productDescription")


        val textProductName = findViewById<TextView>(R.id.tituloTxt)
        val textProductPrice = findViewById<TextView>(R.id.precioTxt)
        val spinnerSizes = findViewById<Spinner>(R.id.spinner_sizes)
        val spinnerColors = findViewById<Spinner>(R.id.spinner_colors)
        val textProductDescription = findViewById<TextView>(R.id.descripcionTxt)

        textProductName.text = productName
        textProductPrice.text = productPrice
        spinnerSizes.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, sizes!!)
        spinnerColors.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, colors!!)
        textProductDescription.text = productDescription

        val imageSlider: ImageSlider = findViewById(R.id.slider)
        val images = ArrayList<SlideModel>()

        when(productName){
            "Pantalon deportivo" -> {
                images.add(SlideModel(R.drawable.pop1, "",null))
                images.add(SlideModel(R.drawable.pop11, "",null))
                images.add(SlideModel(R.drawable.pop12, "",null))
            }
            "Shorts" -> {
                images.add(SlideModel(R.drawable.pop2, "",null))
                images.add(SlideModel(R.drawable.pop21, "",null))
                images.add(SlideModel(R.drawable.pop22, "",null))
            }
            "Tennies" -> {
                images.add(SlideModel(R.drawable.pop3, "",null))
                images.add(SlideModel(R.drawable.pop31, "",null))
                images.add(SlideModel(R.drawable.pop32, "",null))
            }
            "Playera deportiva" -> {
                images.add(SlideModel(R.drawable.pop4, "",null))
                images.add(SlideModel(R.drawable.pop41, "",null))
                images.add(SlideModel(R.drawable.pop42, "",null))
            }

        }

        imageSlider.setImageList(images)



    }
}


