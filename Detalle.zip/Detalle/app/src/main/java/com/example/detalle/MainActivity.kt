package com.example.detalle

import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val button1 = findViewById<ImageButton>(R.id.pop1)
        val button2 = findViewById<ImageButton>(R.id.pop2)
        val button3 = findViewById<ImageButton>(R.id.pop3)
        val button4 = findViewById<ImageButton>(R.id.pop4)

        button1.setOnClickListener {
            openDetailActivity("Pantalon deportivo",  "$1000", arrayOf("S", "M", "L"), arrayOf("Rojo", "Azul", "Verde"),"Lorem ipsum dolor sit amet, consectetur"
+"adipiscing elit Morbi rutrum"
+"ac elit sed ornare Curabitur suscipit eros non malesuada cursus Phasellus"
+"hendrerit tincidunt ultricies Nulla tellus lorem, finibus vel condimentum at,")
        }

        button2.setOnClickListener {
            openDetailActivity("Shorts", "$600", arrayOf("7", "8", "9"), arrayOf("Blanco", "Negro"),"Lorem ipsum dolor sit amet, consectetur"
+"adipiscing elit Morbi rutrum"
+"ac elit sed ornare Curabitur suscipit eros non malesuada cursus Phasellus"
+"hendrerit tincidunt ultricies Nulla tellus lorem, finibus vel condimentum at,"
+"interdum et felis. Nulla facilisis ligula accumsan ornare condimentum. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Cras a"
+"ligula a ipsum maximus ullamcorper a id dolor.")
        }

        button3.setOnClickListener {
            openDetailActivity("Tennies", "$1200", arrayOf("Única"), arrayOf("Blanco", "Negro"),"Lorem ipsum dolor sit amet, consectetur"
+"adipiscing elit Morbi rutrum"
+"ac elit sed ornare Curabitur suscipit eros non malesuada cursus Phasellus"
+"hendrerit tincidunt ultricies Nulla tellus lorem, finibus vel condimentum at,"
+"interdum et felis. Nulla facilisis ligula accumsan ornare condimentum. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Cras a"
+"ligula a ipsum maximus ullamcorper a id dolor.")
        }

        button4.setOnClickListener {
            openDetailActivity("Playera deportiva", "$800", arrayOf("S", "M", "L"), arrayOf("Negro", "Azul"),"Lorem ipsum dolor sit amet, consectetur"
+"adipiscing elit Morbi rutrum"
+"ac elit sed ornare Curabitur suscipit eros non malesuada cursus Phasellus"
+"hendrerit tincidunt ultricies Nulla tellus lorem, finibus vel condimentum at,"
+"interdum et felis. Nulla facilisis ligula accumsan ornare condimentum. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Cras a"
+"ligula a ipsum maximus ullamcorper a id dolor.")
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun openDetailActivity(productName: String, productPrice: String, sizes: Array<String>, colors: Array<String>, productDescription: String) {
        val intent = Intent(this, Detalle::class.java)
        intent.putExtra("productName", productName)
        intent.putExtra("productPrice", productPrice)
        intent.putExtra("sizes", sizes)
        intent.putExtra("colors", colors)
        intent.putExtra("productDescription", productDescription)

        startActivity(intent)
    }

}