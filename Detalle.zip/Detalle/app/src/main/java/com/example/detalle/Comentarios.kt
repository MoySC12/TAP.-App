package com.example.detalle

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class Comentarios : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_comentarios)

        val textComentarios = findViewById<TextInputEditText>(R.id.editTxt).text


        val sendBttn = findViewById<ImageButton>(R.id.sendBttn)
        sendBttn.setOnClickListener{
            val textComentar = findViewById<TextView>(R.id.textView4)
            textComentar.text = textComentarios
        }





    }
}